import pygame
import os

# 가천대 학부생이 과제와 시험들을 무찌르고 무사히 학점을 얻어내는 게임

'''
pygame 인터프리터를 꼭 다운로드 해주세요, 각종 이미지에 대한 경로를 확인해주세요.

[게임 조건]
1. 학부생은 화면 아래에 위치, 좌우로만 이동 가능
2. 스페이스를 누르면 볼펜에서 잉크를 쏘아 올림
3. 큰 과제 1개가 나타나서 바운스
4. 잉크에 닿으면 과제는 작은 과제 2개로 분할, 가장 작은 크기의 과제는 사라짐
5. 모든 과제를 없애면 게임 종료 (정상적 학점 이수)
6. 학부생은 과제에 닿으면 게임 종료 (실패)
7. 제출 기한 99초 초과 시 게임 종료 (실패)
8. FPS는 30으로 고정 (필요시 speed 값을 조정)

[게임 이미지]
1. 배경 : 640 * 480 (가로, 세로) - background.png
2. 무대 : 640 * 50 - stage.png
3. 캐릭터 : 33 * 60 - character.png
4. 볼펜 : 20 * 430 - pen.png
5. 과제 : 160 * 160, 80 * 80, 40* 40, 20 * 20 - task1.png ~ task4.png
'''

#######################################################################################################################

# 기본 초기화
pygame.init()

# 화면 크기 설정
screen_width = 480 # 가로크기
screen_height = 640 # 세로크기

screen = pygame.display.set_mode((screen_width, screen_height))

# 화면 타이틀 설정
pygame.display.set_caption("Gachon Score Hunter") # 게임 이름

# FPS
clock = pygame.time.Clock()

#######################################################################################################################

# 1. 사용자 게임 초기화 (배경화면, 게임 이미지, 좌표, 속도, 폰트 등)
current_path = os.path.dirname(__file__) # 현재 파일의 위치 반환
image_path = os.path.join(current_path, "images") # 이미지 폴더 위치 반환

# 배경 이미지 불러오기
background = pygame.image.load(os.path.join(image_path, "background.png"))

# 스테이지 만들기
stage = pygame.image.load(os.path.join(image_path, "stage.png"))
stage_size = stage.get_rect().size
stage_height = stage_size[1] # 스테이지의 높이 위에 캐릭터를 두기

# 캐릭터 스프라이트 불러오기
character = pygame.image.load(os.path.join(image_path, "character.png"))
character_size = character.get_rect().size # 이미지 크기를 구해옴
character_width = character_size[0] # 캐릭터의 가로 크기
character_height = character_size[1] # 캐릭터의 세로 크기
character_x_pos =  (screen_width / 2) - (character_width / 2)
character_y_pos = screen_height - character_height - stage_height

# 캐릭터 이동 방향
character_to_x = 0

# 캐릭터 이동 속도
character_speed = 5

# 볼펜 만들기
pen = pygame.image.load(os.path.join(image_path, "pen.png"))
pen_size = pen.get_rect().size
pen_width = pen_size[0]

# 잉크는 한번에 여러 발 발사 가능
pens = []

# 잉크 이동 속도
pen_speed = 5

# 과제 만들기 (4개 크기에 대해 따로 처리)
task_images = [
    pygame.image.load(os.path.join(image_path, "task1.png")),
    pygame.image.load(os.path.join(image_path, "task2.png")),
    pygame.image.load(os.path.join(image_path, "task3.png")),
    pygame.image.load(os.path.join(image_path, "task4.png"))]

# 과제 크기에 따른 최초 스피드
task_speed_y = [-18, -15, -12, -9] # index 0, 1, 2, 3에 해당하는 값

# 과제들
tasks = []

# 최초 발생 과제
tasks.append({
    "pos_x" : 50, # 과제의 x 좌표
    "pos_y" : 50, # 과제의 y 좌표
    "img_idx" : 0, # 과제의 이미지 인덱스
    "to_x" : 3, # x축 이동방향
    "to_y" : -6, # y축 이동방향
    "init_spd_y" : task_speed_y[0]}) # y 최초 속도

# 사라질 잉크, 과제 정보 저장 변수
pen_to_remove = -1
task_to_remove = -1

# 폰트 정의
game_font = pygame.font.Font(None, 40) # 폰트 객체 생성 (디폴트 폰트, 크기)

# 총 시간
total_time = 100

# 시작 시간
start_ticks = pygame.time.get_ticks() # 현재 tick 을 받아옴

# 게임 종료 메세지 / 과제 제출 시간 초과, 과제 제출 성공, 낙제
game_result = "Submission Failed."
#######################################################################################################################

# 이벤트 루프
running = True # 게임이 진행중인가?

while running:
    dt = clock.tick(30) # 게임 화면의 초당 프레임 수

    # 2. 이벤트 처리 (키보드, 마우스 등)
    for event in pygame.event.get(): # 어떤 이벤트가 발생하였는가?
        if event.type == pygame.QUIT: # 창이 닫히는 이벤트가 발생하였는가?
            running = False # 게임이 진행중이 아님

        if event.type == pygame.KEYDOWN: # 키가 눌러졌는지 확인
            if event.key == pygame.K_LEFT: # 캐릭터를 왼쪽으로
                character_to_x -= character_speed
            elif event.key == pygame.K_RIGHT: # 캐릭터를 오른쪽으로
                character_to_x += character_speed

            elif event.key == pygame.K_SPACE: # 잉크 발사
                pen_x_pos = character_x_pos + (character_width / 2) - (pen_width / 2)
                pen_y_pos = character_y_pos
                pens.append([pen_x_pos, pen_y_pos])

        if event.type == pygame.KEYUP: # 방향키를 떼면 멈춤
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                character_to_x = 0

    # 3. 게임 캐릭터 위치 정의
    character_x_pos += character_to_x

    if character_x_pos < 0: # 가로 경계값 처리
        character_x_pos = 0
    elif character_x_pos > screen_width - character_width:
        character_x_pos = screen_width - character_width

    # 펜 위치 조정 (어려움 주의)
    pens = [ [p[0], p[1] - pen_speed] for p in pens] # 잉크를 발사

    # 천장에 닿은 잉크 없애기
    pens = [ [ p[0], p[1] ] for p in pens if p[1] > 0]

    # 과제 위치 정의
    for task_idx, task_val in enumerate(tasks):
        task_pos_x = task_val["pos_x"]
        task_pos_y = task_val["pos_y"]
        task_img_idx = task_val["img_idx"]

        task_size = task_images[task_img_idx].get_rect().size
        task_width = task_size[0]
        task_height = task_size[1]

        # 가로벽에 닿았을 때 과제 이동 위치 변경
        if task_pos_x < 0 or task_pos_x > screen_width - task_width:
            task_val["to_x"] = task_val["to_x"] * -1

        # 세로 위치, 스테이지에 튕겨서 올라가는 처리
        if task_pos_y >= screen_height - stage_height - task_height:
            task_val["to_y"] = task_val["init_spd_y"]
        else: # 그 외의 모든 경우, 속도를 증가
            task_val["to_y"] += 0.5

        task_val["pos_x"] += task_val["to_x"]
        task_val["pos_y"] += task_val["to_y"]


    # 4. 충돌 처리

    # 캐릭터 rect 정보 업데이트
    character_rect = character.get_rect()
    character_rect.left = character_x_pos
    character_rect.top = character_y_pos

    for task_idx, task_val in enumerate(tasks):
        task_pos_x = task_val["pos_x"]
        task_pos_y = task_val["pos_y"]
        task_img_idx = task_val["img_idx"]

        # 과제 rect 정보 업데이트
        task_rect = task_images[task_img_idx].get_rect()
        task_rect.left = task_pos_x
        task_rect.top = task_pos_y

        # 과제와 캐릭터 충돌 처리
        if character_rect.colliderect(task_rect):
            running = False
            break

        # 과제와 잉크들 충돌 처리
        for pen_idx, pen_val in enumerate(pens):
            pen_pos_x = pen_val[0]
            pen_pos_y = pen_val[1]

            # 잉크 rect 정보 업데이트
            pen_rect = pen.get_rect()
            pen_rect.left = pen_pos_x
            pen_rect.top = pen_pos_y

            # 충돌 처리
            if pen_rect.colliderect(task_rect):
                pen_to_remove = pen_idx # 해당 잉크 없애기 위한 값 설정
                task_to_remove = task_idx # 해당 과제 없애기 위한 값 설정

                # 가장 작은 크기의 과제가 아니라면 나눠주기

                if task_img_idx < 3:
                    # 현재 과제 크기 정보
                    task_width = task_rect.size[0]
                    task_height = task_rect.size[1]

                    # 나눠진 과제 정보
                    small_task_rect = task_images[task_img_idx + 1].get_rect()
                    small_task_width = small_task_rect.size[0]
                    small_task_height = small_task_rect.size[1]

                    # 왼쪽으로 튕김
                    tasks.append({
                        "pos_x": task_pos_x + (task_width / 2) - (small_task_width / 2),  # 과제의 x 좌표
                        "pos_y": task_pos_y + (task_height / 2) + (small_task_height / 2),  # 과제의 y 좌표
                        "img_idx": task_img_idx + 1,  # 과제의 이미지 인덱스
                        "to_x": -3,  # x축 이동방향
                        "to_y": -6,  # y축 이동방향
                        "init_spd_y": task_speed_y[task_img_idx + 1]})  # y 최초 속도


                    # 오른쪽으로 튕김
                    tasks.append({
                        "pos_x": task_pos_x + (task_width / 2) - (small_task_width / 2),  # 과제의 x 좌표
                        "pos_y": task_pos_y + (task_height / 2) + (small_task_height / 2),  # 과제의 y 좌표
                        "img_idx": task_img_idx + 1,  # 과제의 이미지 인덱스
                        "to_x": 3,  # x축 이동방향
                        "to_y": -6,  # y축 이동방향
                        "init_spd_y": task_speed_y[task_img_idx + 1]})  # y 최초 속도

                break

        # 충돌된 괘제 or 잉크 없애기
        if task_to_remove > -1:
            del tasks[task_to_remove]
            task_to_remove = -1
        if pen_to_remove > -1:
            del pens[pen_to_remove]
            pen_to_remove = -1

        # 모든 과제를 한 경우 게임 종료
        if len(tasks) == 0:
            game_result = "Submission Complete"
            running = False


    # 5. 화면에 그리기
    screen.blit(background, (0, 0)) # 배경 그리기

    for pen_x_pos, pen_y_pos in  pens: # 펜 그리기
        screen.blit(pen, (pen_x_pos, pen_y_pos))

    for idx, val in enumerate(tasks):
        task_pos_x = val["pos_x"]
        task_pos_y = val["pos_y"]
        task_img_idx = val["img_idx"]
        screen.blit(task_images[task_img_idx], (task_pos_x, task_pos_y))

    screen.blit(stage, (0, screen_height - stage_height)) # 스테이지 그리기
    screen.blit(character, (character_x_pos, character_y_pos)) # 캐릭터 그리기

    # 경과 시간 계산

    elapsed_time = (pygame.time.get_ticks() - start_ticks) / 1000 # 경과 시간(ms) 계산, 초(s) 단위로 표시시

    timer = game_font.render("Submission Deadline is {}seconds left.".format(int(total_time - elapsed_time)), True, (0, 0 ,0))
    screen.blit(timer, (10, 10))

    if total_time - elapsed_time <= 0:
        game_result = "Submission Failed."
        running = False

    pygame.display.update()  # 게임화면을 다시 그리기 !!!!!!!!!!!!!!

text = game_font.render(game_result, True, (255, 0, 0))
text_rect = text.get_rect(center = (int(screen_width / 2), int(screen_height / 2)))
screen.blit(text, text_rect)

pygame.display.update()

#######################################################################################################################

# 잠시 대기
pygame.time.delay(2000) # 2초 정도 대기 (ms)

# 게임 종료
pygame.quit()